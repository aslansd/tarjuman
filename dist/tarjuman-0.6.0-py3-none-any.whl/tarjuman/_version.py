"""Single source of truth for the package version."""

__version__ = "0.6.0"
